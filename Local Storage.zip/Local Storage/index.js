
function armazenarInput(){
    let l = document.getElementById('senha').value
    localStorage.setItem('Valor Número', l)
}